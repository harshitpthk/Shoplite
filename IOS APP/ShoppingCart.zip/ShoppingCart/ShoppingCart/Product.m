//
//  Product.m
//  ShoppingCart
//
//  Created by Sunkara, Radha Phani on 08/10/14.
//  Copyright (c) 2014 com.sample.shoppingcart. All rights reserved.
//

#import "Product.h"

@implementation Product

-(ProductVarience *)getSelectedVareince
{
    return [self.varienceList  objectAtIndex:self.varienceSelected];
}
@end
