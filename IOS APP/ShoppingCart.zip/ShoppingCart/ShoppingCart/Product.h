//
//  Product.h
//  ShoppingCart
//
//  Created by Sunkara, Radha Phani on 08/10/14.
//  Copyright (c) 2014 com.sample.shoppingcart. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ProductVarience.h"

@interface Product : NSObject

@property(nonatomic) NSUInteger id;
@property(nonatomic,retain) NSString *name;
@property(nonatomic) NSUInteger categoryId;
@property(nonatomic) NSUInteger brandId;
@property(nonatomic,retain) NSMutableArray *varienceList;
@property(nonatomic) NSUInteger varienceSelected;
@property(nonatomic) NSUInteger quantitySelected;

-(ProductVarience *)getSelectedVareince;
@end
