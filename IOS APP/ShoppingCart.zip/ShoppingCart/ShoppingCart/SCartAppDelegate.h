//
//  SCartAppDelegate.h
//  ShoppingCart
//
//  Created by Ayyanababu, Kopparthi Raja on 09/09/14.
//  Copyright (c) 2014 com.sample.shoppingcart. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface SCartAppDelegate : UIResponder <UIApplicationDelegate>
{
    UINavigationController *SCNavController;
    
}

@property (strong, nonatomic) UIWindow                  *window;
@property (strong, nonatomic) UINavigationController    *SCNavController;

- (void) launchMainScreen;
- (void) launchSignUpScreen;
- (void) launchGetStartedScreen;

@end
