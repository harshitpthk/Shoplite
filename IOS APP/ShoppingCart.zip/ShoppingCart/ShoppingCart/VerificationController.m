//
//  SCartVerifyController.m
//  ShoppingCart
//
//  Created by Ayyanababu, Kopparthi Raja on 09/09/14.
//  Copyright (c) 2014 com.sample.shoppingcart. All rights reserved.
//

#import "VerificationController.h"
#import "ConnectionManager.h"
#import "KeychainWrapper.h"
#import "AESCrypt.h"
#import "NSData+CommonCrypto.h"
#import "NSData+Base64.h"

@interface VerificationController ()

@end

@implementation VerificationController


@synthesize  screenTitle;
@synthesize  msgBox;
@synthesize  verifiedPhoneNumber;
@synthesize  verificationCode;
@synthesize  verifyButton;
@synthesize  resendButton;
@synthesize  signUpAgainButton;
@synthesize  verificatinErrorMsg;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        
        //Veify Tite Lable
        self.screenTitle = [[UILabel alloc] init];
        [self.screenTitle setText:@"Verify"];
        [self.screenTitle setTextColor:[UIColor purpleColor]];
        self.screenTitle.layer.borderColor = [UIColor purpleColor].CGColor;
        [self.screenTitle setFont:[UIFont fontWithName:@"HelveticaNeue-Thin" size:25.0f]];
        self.screenTitle.textAlignment = NSTextAlignmentLeft;
        
        
        self.msgBox = [[UILabel alloc] init];
        [self.msgBox setText:@"We have sent a code for verifying you as a real person, please enter the code received on your phone numbered"];
        [self.msgBox setTextColor:[UIColor blackColor]];
        self.msgBox.layer.borderColor = [UIColor purpleColor].CGColor;
        [self.msgBox setFont:[UIFont fontWithName:@"HelveticaNeue-Bold" size:11.0f]];
        self.msgBox.textAlignment = NSTextAlignmentLeft;
        self.msgBox.numberOfLines = 0;
        
        self.verifiedPhoneNumber = [[UITextField alloc] initWithFrame:CGRectZero];
        self.verifiedPhoneNumber.placeholder = @"Verification Number";
        self.verifiedPhoneNumber.textAlignment = NSTextAlignmentLeft;
        self.verifiedPhoneNumber.font = [UIFont fontWithName:@"HelveticaNeue-Thin" size:14.0];
        self.verifiedPhoneNumber.adjustsFontSizeToFitWidth = YES;
        self.verifiedPhoneNumber.textColor = [UIColor blackColor];
        self.verifiedPhoneNumber.keyboardType = UIKeyboardTypeAlphabet;
        self.verifiedPhoneNumber.returnKeyType = UIReturnKeyDone;
        self.verifiedPhoneNumber.clearButtonMode = UITextFieldViewModeWhileEditing;
        
        
        self.verificationCode = [[UITextField alloc] initWithFrame:CGRectZero];
        self.verificationCode.placeholder = @"Unknown Field to Clarify";
        self.verificationCode.textAlignment = NSTextAlignmentLeft;
        self.verificationCode.font = [UIFont fontWithName:@"HelveticaNeue-Thin" size:14.0];
        self.verificationCode.adjustsFontSizeToFitWidth = YES;
        self.verificationCode.textColor = [UIColor blackColor];
        self.verificationCode.keyboardType = UIKeyboardTypeEmailAddress;
        self.verificationCode.returnKeyType = UIReturnKeyDone;
        self.verificationCode.clearButtonMode = UITextFieldViewModeWhileEditing;
        
        
        self.verifyButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        [self.verifyButton setTitle:@"Verify" forState:UIControlStateNormal];
        [self.verifyButton setTitleColor:[UIColor purpleColor] forState:UIControlStateNormal];
        self.verifyButton.layer.cornerRadius = 4;
        self.verifyButton.layer.borderWidth = 0.5;
        self.verifyButton.layer.borderColor = [UIColor purpleColor].CGColor;
        [self.verifyButton.titleLabel setFont:[UIFont fontWithName:@"HelveticaNeue-Thin" size:16.0f]];
        [self.verifyButton.titleLabel setTextAlignment:NSTextAlignmentCenter];
        [self.verifyButton addTarget:self action:@selector(verify) forControlEvents:UIControlEventTouchDown];
        
        self.resendButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        [self.resendButton setTitle:@"Resend" forState:UIControlStateNormal];
        [self.resendButton setTitleColor:[UIColor purpleColor] forState:UIControlStateNormal];
        self.resendButton.layer.cornerRadius = 4;
        self.resendButton.layer.borderWidth = 0.5;
        self.resendButton.layer.borderColor = [UIColor purpleColor].CGColor;
        [self.resendButton.titleLabel setFont:[UIFont fontWithName:@"HelveticaNeue-Thin" size:16.0f]];
        [self.resendButton.titleLabel setTextAlignment:NSTextAlignmentCenter];
        [self.resendButton addTarget:self action:@selector(resend) forControlEvents:UIControlEventTouchDown];
        
        self.signUpAgainButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        [self.signUpAgainButton setTitle:@"Sign Up Again" forState:UIControlStateNormal];
        [self.signUpAgainButton setTitleColor:[UIColor purpleColor] forState:UIControlStateNormal];
        self.signUpAgainButton.layer.cornerRadius = 4;
        self.signUpAgainButton.layer.borderWidth = 0.5;
        self.signUpAgainButton.layer.borderColor = [UIColor purpleColor].CGColor;
        [self.signUpAgainButton.titleLabel setFont:[UIFont fontWithName:@"HelveticaNeue-Thin" size:16.0f]];
        [self.signUpAgainButton.titleLabel setTextAlignment:NSTextAlignmentCenter];
        [self.signUpAgainButton addTarget:self action:@selector(gotoSignUpAgainScreen) forControlEvents:UIControlEventTouchDown];
        
        
        //Error msg display label initially hidden
        self.verificatinErrorMsg = [[UILabel alloc] init];
        [self.verificatinErrorMsg setText:@"Wrong Verifycation code try again"];
        [self.verificatinErrorMsg setTextColor:[UIColor redColor]];
        self.verificatinErrorMsg.layer.borderColor = [UIColor purpleColor].CGColor;
        [self.verificatinErrorMsg setFont:[UIFont fontWithName:@"HelveticaNeue-Thin" size:13.0f]];
        self.verificatinErrorMsg.textAlignment = NSTextAlignmentCenter;
        self.verificatinErrorMsg.hidden = YES;
        
        
        [self.view addSubview:self.screenTitle];
        [self.view addSubview:self.msgBox];
        [self.view addSubview:self.verifiedPhoneNumber];
        [self.view addSubview:self.verificationCode];
        [self.view addSubview:self.verifyButton];
        [self.view addSubview:self.resendButton];
        [self.view addSubview:self.signUpAgainButton];
        [self.view addSubview:self.verificatinErrorMsg];


        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    
    

    // Do any additional setup after loading the view.
    
    [self.screenTitle setFrame:CGRectMake(20, self.view.frame.origin.y + 20, 150, 100)];
    [self.msgBox setFrame:CGRectMake(20, self.screenTitle.frame.size.height-20, self.view.frame.size.width - 20, 60)];
    [self.verifiedPhoneNumber setFrame:CGRectMake(20, self.msgBox.frame.origin.y + self.msgBox.frame.size.height + 10, self.view.frame.size.width-20, 40)];
    [self.verificationCode setFrame:CGRectMake(20, self.verifiedPhoneNumber.frame.origin.y+self.verifiedPhoneNumber.frame.size.height + 10,self.view.frame.size.width - 20 , 40)];
    [self.verifyButton setFrame:CGRectMake(20, self.verificationCode.frame.origin.y+self.verificationCode.frame.size.height + 20, self.view.frame.size.width/3-30, 40)];
    [self.resendButton setFrame:CGRectMake(self.verifyButton.frame.size.width+ 25, self.verificationCode.frame.origin.y+self.verificationCode.frame.size.height + 20, self.view.frame.size.width/3-30, 40)];
    [self.signUpAgainButton setFrame:CGRectMake(self.resendButton.frame.size.width+ self.verifyButton.frame.size.width + 30, self.verificationCode.frame.origin.y+self.verificationCode.frame.size.height + 20, self.view.frame.size.width/3+5, 40)];
    
    [self.verificatinErrorMsg setFrame:CGRectMake(20, self.signUpAgainButton.frame.origin.y+self.signUpAgainButton.frame.size.height + 25, self.view.frame.size.width - 20, 50)];

}

-(void)verify
{
    NSError *error =nil;
    NSNumber *number = [NSNumber  numberWithInt:[self.verificationCode.text integerValue]];
    NSArray *array = [NSArray arrayWithObject:number];
    
    NSData *jsonData=[NSJSONSerialization dataWithJSONObject:array options:NSJSONWritingPrettyPrinted error:&error];
    
    ConnectionManager *manager = [ConnectionManager getInstance];
    
    NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:nil];
    [manager prepareRequestForStarConnection:postRequest withService:@"adduser" isPost:YES];
    [postRequest setHTTPBody:jsonData];
    
    HttpsOperations *operation = [[HttpsOperations alloc] initWithRequest:postRequest withDelegate:self];
    [manager.serailQueue addOperation:operation];
    
}

- (void) verifyAndLaunchMainScreen
{
    [[Utility getApplicationRootClass] launchMainScreen];
}


- (void) resend
{
    
    KeychainWrapper *keyChain = [KeychainWrapper getInstance];
    NSData *data = [keyChain myObjectForKey:(__bridge id)kSecAttrAccount];
    NSDictionary *dict = [NSKeyedUnarchiver unarchiveObjectWithData:(NSData *)data];
    
    NSError *error =nil;
    NSData *jsonData=[NSJSONSerialization dataWithJSONObject:dict options:NSJSONWritingPrettyPrinted error:&error];
    
    ConnectionManager *manager = [ConnectionManager getInstance];
    
    NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:nil];
    [manager prepareRequestForStarConnection:postRequest withService:@"registeruser" isPost:YES];
    [postRequest setHTTPBody:jsonData];
    
    HttpsOperations *operation = [[HttpsOperations alloc] initWithRequest:postRequest withDelegate:self];
    [manager.serailQueue addOperation:operation];
    
     resendOperation = operation;
    
}

- (void) gotoSignUpAgainScreen
{
    [self.navigationController popViewControllerAnimated:NO];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - opeartion delegate

-(void)operationFinishedWithdata:(HttpsOperations *)operation
{
    if(![operation isEqual:resendOperation])
    {
        NSError *e = nil;
        NSArray *array = [NSJSONSerialization JSONObjectWithData:operation.receivedData options: NSJSONReadingMutableContainers error: &e];
        
        if(array==nil || [array count]<1)
        {
            //throw error
        }

        NSString *encodedString  = [array objectAtIndex:0];
        NSString *decodedString = [Utility decrypt:encodedString withKey:[Utility getSecurityKeyName]];
         KeychainWrapper *keyChain = [KeychainWrapper getInstance];
        [keyChain mySetObject:decodedString forKey:(__bridge id)kSecValueData];
        [self verifyAndLaunchMainScreen];
    }
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
