//
//  ProductTableViewCell.m
//  ShoppingCart
//
//  Created by Sunkara, Radha Phani on 14/10/14.
//  Copyright (c) 2014 com.sample.shoppingcart. All rights reserved.
//

#import "ProductTableViewCell.h"

@implementation ProductTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (id)initWithProduct:(Product *)product reuseIdentifier:CellIdentifier
{
    self = [super initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    if (self) {
        // Initialization code
       

        self.productImageView = [[UIImageView alloc] initWithFrame:CGRectMake(5, 2.5, 75, 75)];
        self.title = [[UILabel alloc] initWithFrame:CGRectMake(85, 0, self.frame.size.width-75-2*5, 30)];
        self.vareinceTitle = [[UILabel alloc] initWithFrame:CGRectMake(85, 32, self.frame.size.width-75-2*5, 20)];
        
        UIButton *editButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [editButton setFrame:CGRectMake(self.frame.size.width-35, 32, 35, 20)];
        
        int part = (self.frame.size.width-85)/3;
        
        self.price = [[UILabel alloc] initWithFrame:CGRectMake(85, 55, part-10, 25)];
        
        UILabel *labelStar = [[UILabel alloc] initWithFrame:CGRectMake(85+part-10, 55, 5, 25)];
        self.quantity = [[UILabel alloc] initWithFrame:CGRectMake(85+part-5, 55, part-10, 25)];
        
        UILabel *labelEqual = [[UILabel alloc] initWithFrame:CGRectMake(85+2*part-15, 55, 5, 25)];
        self.total = [[UILabel alloc] initWithFrame:CGRectMake(85+2*part-10, 55, part-5, 25)];
       
        
        [self.title setFont:[UIFont fontWithName:@"HelveticaNeue-Thin" size:16.0f]];
        [self.price setFont:[UIFont fontWithName:@"HelveticaNeue-Thin" size:14.0f]];
        [self.quantity setFont:[UIFont fontWithName:@"HelveticaNeue-Thin" size:14.0f]];
        [self.vareinceTitle setFont:[UIFont fontWithName:@"HelveticaNeue-Thin" size:14.0f]];
        [self.total setFont:[UIFont fontWithName:@"HelveticaNeue-Thin" size:14.0f]];
        
        [labelStar setFont:[UIFont fontWithName:@"HelveticaNeue-Thin" size:12.0f]];
        [labelEqual setFont:[UIFont fontWithName:@"HelveticaNeue-Thin" size:12.0f]];
        [editButton.titleLabel setFont:[UIFont fontWithName:@"HelveticaNeue-Thin" size:14.0f]];
        
        
        [self.title setTextAlignment:NSTextAlignmentLeft];
        [self.vareinceTitle setTextAlignment:NSTextAlignmentLeft];
        [self.price setTextAlignment:NSTextAlignmentLeft];
        [self.quantity setTextAlignment:NSTextAlignmentCenter];
        [self.total setTextAlignment:NSTextAlignmentRight];
        
        self.productImageView.image = [UIImage imageNamed:@"product.gif"];
        self.title.text = product.name;
        
        ProductVarience *varience =  [product getSelectedVareince];
        
        self.vareinceTitle.text = varience.name;
        self.quantity.text = [NSString stringWithFormat:@"%d Units",(int)product.quantitySelected];
        self.price.text = [NSString stringWithFormat:@"%0.2f ₹",varience.price];
        self.total.text = [NSString stringWithFormat:@"%0.2f ₹",(varience.price * (int)product.quantitySelected)];
    
        labelStar.text=@"*";
        labelEqual.text=@"=";
        editButton.titleLabel.text=@"Edit";
        
        [editButton addTarget:self action:@selector(goToEditMode) forControlEvents:UIControlEventTouchDown];
    
        
        [self addSubview:self.productImageView];
        [self addSubview:self.title];
        [self addSubview:self.vareinceTitle];
        [self addSubview:self.quantity];
        [self addSubview:self.price];
        [self addSubview:self.total];
        
        [self addSubview:labelStar];
        [self addSubview:labelEqual];
        [self addSubview:editButton];x`
        
        self.currentProduct =product;
        
    }
    return self;
}

-(void)goToEditMode
{
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height)];
    
    if(self.currentProduct.varienceList.count >0)
    {
        self.variencePicker = [[UIPickerView alloc] initWithFrame:CGRectMake(self.frame.size.width/2-20, 25, 40, 300)];
        [self.variencePicker setDelegate:self];
        [self.variencePicker setDataSource:self];
        self.variencePicker.showsSelectionIndicator =YES;
        self.variencePicker.backgroundColor = [UIColor clearColor];
        CGAffineTransform rotate = CGAffineTransformMakeRotation(-3.14/2);
        [self.variencePicker setTransform:rotate];
        self.variencePicker.autoresizingMask = UIViewAutoresizingFlexibleHeight|UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleLeftMargin|UIViewAutoresizingFlexibleRightMargin|UIViewAutoresizingFlexibleTopMargin;;
        [view addSubview:self.variencePicker];
        
        self.currentProduct.varienceSelected = 0;
        
        ProductVarience *varience =[self.currentProduct getSelectedVareince];
        self.price.text = [NSString stringWithFormat:@"%0.2f",varience.price];
        
        if(varience.quantity>0)
        {
            
             self.currentProduct.quantitySelected =1;
            
            self.quantityPicker = [[UIPickerView alloc] initWithFrame:CGRectMake(self.frame.size.width/2-20,75, 30, 300)];
            [self.quantityPicker setDelegate:self];
            [self.quantityPicker setDataSource:self];
            self.quantityPicker.showsSelectionIndicator =YES;
            self.quantityPicker.backgroundColor = [UIColor clearColor];
            CGAffineTransform rotate = CGAffineTransformMakeRotation(-3.14/2);
            [self.quantityPicker setTransform:rotate];
            [view addSubview:self.quantityPicker];
            
            
            
        }
    }
    
    CGAffineTransform rotate = CGAffineTransformMakeRotation(-3.14/2);
    [view setTransform:rotate];
    
    [self addSubview:view];
    
    rotate = CGAffineTransformMakeRotation(3.14/2);
    [self setTransform:rotate];
}

#pragma pickerview delegate

- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view
{
    
    CGRect rect=CGRectZero;
    
    if([pickerView isEqual:self.variencePicker])
    {
        rect = CGRectMake(0, 0, 80, 40);
        
    }else
    {
        rect = CGRectMake(0, 0, 60, 30);
    }
    
    UILabel *label = [[UILabel alloc]initWithFrame:rect];
    CGAffineTransform rotate = CGAffineTransformMakeRotation(3.14/2);
    //rotate = CGAffineTransformScale(rotate, 0.25, 2.0);
    [label setTransform:rotate];
    
    label.font = [UIFont systemFontOfSize:22.0];
    label.textAlignment = NSTextAlignmentCenter;
    label.numberOfLines = 2;
    label.lineBreakMode = NSLineBreakByWordWrapping;
    label.backgroundColor = [UIColor clearColor];
    label.clipsToBounds = YES;
    [label setFont:[UIFont fontWithName:@"HelveticaNeue-Thin" size:16.0f]];
    
    if([pickerView isEqual:self.variencePicker])
    {
        label.text = [[self.currentProduct.varienceList objectAtIndex:row] name];
        
    }else
    {
        label.text = [NSString stringWithFormat:@"Qty : %d",(int)row+1];
    }
    return label ;
}

-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}

-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    if([pickerView isEqual:self.variencePicker])
    {
        return self.currentProduct.varienceList.count;
        
    }else{
        ProductVarience *varience =  [self.currentProduct getSelectedVareince];
        return varience.quantity+30;
    }
}

-(double)pickerView:(UIPickerView *)pickerView rowHeightForComponent:(NSInteger)component
{
    if([pickerView isEqual:self.variencePicker])
    {
        return 80;
    }else{
        return 60;
    }
}

-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    if([pickerView isEqual:self.variencePicker])
    {
        self.currentProduct.varienceSelected = (int)row;
        ProductVarience *varience =  [self.currentProduct.varienceList objectAtIndex:row];
        self.price.text = [NSString stringWithFormat:@"%0.2f",varience.price];
        
        if(varience.quantity>0)
        {
            self.quantityPicker.hidden=NO;
            [self.quantityPicker reloadAllComponents];
            [self.quantityPicker selectRow:0 inComponent:0 animated:YES];
            
        }else
        {
            self.quantityPicker.hidden=YES;
            
        }
        
    }else
    {
        ProductVarience *varience =  [self.currentProduct getSelectedVareince];
        self.currentProduct.quantitySelected =row+1;
        self.price.text = [NSString stringWithFormat:@"%0.2f",(varience.price)*(row+1)];
    }
}

@end
