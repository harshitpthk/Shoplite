//
//  SCartUtility.h
//  ShoppingCart
//
//  Created by Ayyanababu, Kopparthi Raja on 09/09/14.
//  Copyright (c) 2014 com.sample.shoppingcart. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SCartAppDelegate.h"

@interface Utility : NSObject

+ (SCartAppDelegate *) getApplicationRootClass;
+(NSString *)getSecurityKeyName;
+ (NSString *) encrypt:(NSString *) dataToEncrypt withKey:(NSString*) key;
+ (NSString *) decrypt:(NSString *) dataToDecrypt withKey:(NSString*) key;
+(NSString *)getUniqueSession;
@end
