//
//  SCartUtility.m
//  ShoppingCart
//
//  Created by Ayyanababu, Kopparthi Raja on 09/09/14.
//  Copyright (c) 2014 com.sample.shoppingcart. All rights reserved.
//

#import "Utility.h"
#import <CommonCrypto/CommonCryptor.h>
#import "NSString+Base64.h"
#import "NSData+Base64.h"
#import "RandomGenerator.h"
#import "KeychainWrapper.h"

@implementation Utility

+ (SCartAppDelegate *) getApplicationRootClass
{
        return (SCartAppDelegate *)[UIApplication sharedApplication].delegate;
}

+(NSString *)getSecurityKeyName
{
    return @"thrhIRI8N0A6H*PA";
}

+ (NSString *) encrypt:(NSString *) dataToEncrypt withKey:(NSString*) key{
    
    
    NSData *data = [dataToEncrypt dataUsingEncoding:NSUTF8StringEncoding];
    NSData *mData = [key dataUsingEncoding:NSUTF8StringEncoding];
    
    CCCryptorStatus ccStatus = kCCSuccess;
    
    
    // Begin to calculate bytesNeeded....
    
    size_t bytesNeeded = 0;
    
    ccStatus = CCCrypt(kCCEncrypt,
                       kCCAlgorithmAES,
                       kCCOptionECBMode | kCCOptionPKCS7Padding,
                       [mData bytes],
                       [mData length],
                       nil,
                       [data bytes],
                       [data length],
                       NULL,
                       0,
                       &bytesNeeded);
    
    if(kCCBufferTooSmall != ccStatus){
        
        NSLog(@"Buffer too small");
        return nil;
    }
    
    // .....End
    // Now i do the real Crypting
    
    char* cypherBytes = malloc(bytesNeeded);
    size_t bufferLength = bytesNeeded;
    
    if(NULL == cypherBytes)
        NSLog(@"cypherBytes NULL");
    
    ccStatus = CCCrypt(kCCEncrypt,
                       kCCAlgorithmAES,
                       kCCOptionECBMode | kCCOptionPKCS7Padding,
                       [mData bytes],
                       [mData length],
                       nil,
                       [data bytes],
                       [data length],
                       cypherBytes,
                       bufferLength,
                       &bytesNeeded);
    
    if(kCCSuccess != ccStatus){
        NSLog(@"kCCSuccess NO!");
        return nil;
    }
    
    return [NSString base64StringFromData:[NSData dataWithBytes:cypherBytes length:bufferLength] length:bufferLength];
    //return [Base64 encode:[NSData dataWithBytes:cypherBytes length:bufferLength]];
}

+ (NSString *) decrypt:(NSString *) dataToDecrypt withKey:(NSString*) key{
    
     NSData *data = [NSData base64DataFromString:dataToDecrypt];
     NSData *mData = [key dataUsingEncoding:NSUTF8StringEncoding];
    
    CCCryptorStatus ccStatus = kCCSuccess;
    
    
    // Begin to calculate bytesNeeded....
    
    size_t bytesNeeded = 0;
    
    ccStatus = CCCrypt(kCCDecrypt,
                       kCCAlgorithmAES,
                       kCCOptionECBMode | kCCOptionPKCS7Padding,
                       [mData bytes],
                       [mData length],
                       nil,
                       [data bytes],
                       [data length],
                       NULL,
                       0,
                       &bytesNeeded);
    
    if(kCCBufferTooSmall != ccStatus){
        
        NSLog(@"Buffer too small");
        return nil;
    }
    
    // .....End
    // Now i do the real Crypting
    
    char* cypherBytes = malloc(bytesNeeded);
    size_t bufferLength = bytesNeeded;
    
    if(NULL == cypherBytes)
        NSLog(@"cypherBytes NULL");
    
    ccStatus = CCCrypt(kCCDecrypt,
                       kCCAlgorithmAES,
                       kCCOptionECBMode | kCCOptionPKCS7Padding,
                       [mData bytes],
                       [mData length],
                       nil,
                       [data bytes],
                       [data length],
                       cypherBytes,
                       bufferLength,
                       &bytesNeeded);
    
    if(kCCSuccess != ccStatus){
        NSLog(@"kCCSuccess NO!");
        return nil;
    }
    
    return [[NSString alloc] initWithData:[NSData dataWithBytes:cypherBytes length:bytesNeeded] encoding:NSUTF8StringEncoding];

}

+(NSString *)getUniqueSession
{
    NSTimeInterval time =[[NSDate date] timeIntervalSince1970];
    int factor = (int)time/63000;
    
    NSString *seed = [Utility genarateSeedWithKey:factor withLength:8];
    
    KeychainWrapper *keyChain = [[KeychainWrapper alloc] init];
    NSString *client = [keyChain myObjectForKey:(__bridge id)kSecValueData];

    NSString *str = [NSString stringWithFormat:@"%@%@",client,seed];
    
    str = [Utility encrypt:str withKey:[Utility getSecurityKeyName]];
    
    return str;
}

+(NSString *)genarateSeedWithKey:(long)key withLength:(int)length
{
    RandomGenerator *random = [[RandomGenerator alloc] initWithSeed:key];
    
    NSMutableString *str =[[NSMutableString alloc] init];
    for(int i=0; i<length; ++i) {
        
        int len =[random nextInt:26];
        char c= (char) (65 + len);
        [str appendFormat:@"%c",c];
    }
    return str;
}

@end
