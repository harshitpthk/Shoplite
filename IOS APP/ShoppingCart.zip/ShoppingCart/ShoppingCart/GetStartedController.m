//
//  SCartGetStartedController.m
//  ShoppingCart
//
//  Created by Ayyanababu, Kopparthi Raja on 09/09/14.
//  Copyright (c) 2014 com.sample.shoppingcart. All rights reserved.
//

#import "GetStartedController.h"
#import "SignUpController.h"
#import "AESCrypt.h"

@interface GetStartedController ()

@end

@implementation GetStartedController

@synthesize getStartedLbl;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.getStartedLbl = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self.getStartedLbl setFrame:CGRectMake(50, self.view.frame.size.height-80, self.view.frame.size.width*0.7, 40)];
    [self.getStartedLbl setTitle:@"Get Started" forState:UIControlStateNormal];
    [self.getStartedLbl setTitleColor:[UIColor purpleColor] forState:UIControlStateNormal];
    self.getStartedLbl.layer.cornerRadius = 4;
    self.getStartedLbl.layer.borderWidth = 0.5;
    self.getStartedLbl.layer.borderColor = [UIColor purpleColor].CGColor;
    [self.getStartedLbl.titleLabel setFont:[UIFont fontWithName:@"HelveticaNeue-Thin" size:16.0f]];
    [self.getStartedLbl addTarget:self action:@selector(LaunchSignUpScreen) forControlEvents:UIControlEventTouchDown];
    [self.view addSubview:self.getStartedLbl];
}

- (void) LaunchSignUpScreen
{
    SignUpController *signUpController = [[SignUpController alloc] initWithNibName:nil bundle:nil];
    [self.navigationController pushViewController:signUpController animated:NO];    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
