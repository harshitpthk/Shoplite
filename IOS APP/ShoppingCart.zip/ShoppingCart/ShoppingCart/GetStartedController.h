//
//  SCartGetStartedController.h
//  ShoppingCart
//
//  Created by Ayyanababu, Kopparthi Raja on 09/09/14.
//  Copyright (c) 2014 com.sample.shoppingcart. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GetStartedController : UIViewController
{
    UIButton     *getStartedLbl;
}

@property (strong, nonatomic) UIButton   *getStartedLbl;

@end
