//
//  ProductInfoView1.m
//  ShoppingCart
//
//  Created by Sunkara, Radha Phani on 10/10/14.
//  Copyright (c) 2014 com.sample.shoppingcart. All rights reserved.
//

#import "ProductInfoView1.h"
#import "ConnectionManager.h"

@implementation ProductInfoView1

/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect {
 // Drawing code
 }
 */
-(id)initWithFrame:(CGRect)frame withProduct:(Product *)product
{
    self =[super initWithFrame:frame];
    if(self)
    {
        self.product  = product;
        self.currentProduct = product;
        [self getProductDetails];
        
        
        self.imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 100, 100)];
        self.title = [[UILabel alloc] initWithFrame:CGRectMake(110, 0, self.frame.size.width-100-2*10, 60)];
        self.price = [[UILabel alloc] initWithFrame:CGRectMake(110, 70, self.frame.size.width-100-2*10, 30)];
        self.error = [[UILabel alloc] initWithFrame:CGRectMake(10, 120, self.frame.size.width-2*10, 100)];
        
        
        [self.title setFont:[UIFont fontWithName:@"HelveticaNeue-Thin" size:16.0f]];
        [self.price setFont:[UIFont fontWithName:@"HelveticaNeue-Thin" size:16.0f]];
        [self.error setFont:[UIFont fontWithName:@"HelveticaNeue-Thin" size:16.0f]];
        
        [self.title setTextAlignment:NSTextAlignmentCenter];
        [self.title setLineBreakMode:NSLineBreakByWordWrapping];
        
        [self.price setTextAlignment:NSTextAlignmentCenter];
        [self.error setTextAlignment:NSTextAlignmentCenter];
        
        [self.imageView setImage:[UIImage imageNamed:@"product.jpg"]];
        
        self.addProduct = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        [self.addProduct setTitle:@"Add" forState:UIControlStateNormal];
        [self.addProduct setTitleColor:[UIColor purpleColor] forState:UIControlStateNormal];
        self.addProduct.layer.cornerRadius = 4;
        self.addProduct.layer.borderWidth = 1.0;
        self.addProduct.layer.borderColor = [UIColor purpleColor].CGColor;
        [self.addProduct.titleLabel setFont:[UIFont fontWithName:@"HelveticaNeue-Thin" size:16.0f]];
        [self.addProduct.titleLabel setTextAlignment:NSTextAlignmentRight];
        [self.addProduct addTarget:self action:@selector(addProductToCart) forControlEvents:UIControlEventTouchDown];
        
        [self.addProduct setFrame:CGRectMake(self.frame.size.width-100, self.frame.size.height-50, 80, 40)];
        
    
        [self addSubview:self.imageView];
        [self addSubview:self.title];
        [self addSubview:self.price];
        [self addSubview:self.error];
        [self addSubview:self.addProduct];
    }
    
    return self;
}

-(void)getProductDetails
{
    ConnectionManager *manager = [ConnectionManager getInstance];
    
    NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:nil];
    [manager prepareRequestForShopConnection:postRequest withService:@"getitem" isPost:YES];
    
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
    [dict setObject:@"itemcategoryid" forKey:@"type"];
    [dict setObject:[NSNumber numberWithInteger:self.currentProduct.id] forKey:@"id"];
    
    NSError *error =nil;
    NSData *jsonData=[NSJSONSerialization dataWithJSONObject:dict options:NSJSONWritingPrettyPrinted error:&error];
    
    [postRequest setHTTPBody:jsonData];
    
    HttpsOperations *operation = [[HttpsOperations alloc] initWithRequest:postRequest withDelegate:self];
    [manager.concurrentQueue addOperation:operation];
    
    getProductDetails = operation;
}


#pragma mark - opeartion delegate

-(void)operationFinishedWithdata:(HttpsOperations *)operation
{
    if([operation isEqual:getProductDetails])
    {
        NSError *e = nil;
        NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:operation.receivedData options: NSJSONReadingMutableContainers error: &e];
        
        if(dict!=nil)
        {
            self.currentProduct.brandId = [[dict objectForKey:@"brandId"] integerValue];
            self.currentProduct.name = [dict objectForKey:@"name"];
            self.title.text= [dict objectForKey:@"name"];
            
            
            NSArray *itemList =[dict objectForKey:@"itemList"];
            NSMutableArray *itemsnames = [[NSMutableArray alloc] init];
            
            for(int i=0;i<itemList.count;i++)
            {
                NSDictionary *dictItem = [itemList objectAtIndex:i];
                ProductVarience *item = [[ProductVarience alloc] init];
                item.id =[[dictItem objectForKey:@"id"] integerValue];
                item.name =[dictItem objectForKey:@"name"];
                
                item.price =[[dictItem objectForKey:@"price"] doubleValue];
                item.quantity =[[dictItem objectForKey:@"quantity"] integerValue];
                
                if(!self.currentProduct.varienceList)
                {
                    self.currentProduct.varienceList = [[NSMutableArray alloc] init];
                }
                
                [self.currentProduct.varienceList addObject:item];
                
                [itemsnames addObject:item.name];
                
            }
            
            
            if(self.currentProduct.varienceList.count >0)
            {
                self.variencePicker = [[UIPickerView alloc] initWithFrame:CGRectMake(self.frame.size.width/2-20, 25, 40, 300)];
                [self.variencePicker setDelegate:self];
                [self.variencePicker setDataSource:self];
                self.variencePicker.showsSelectionIndicator =YES;
                self.variencePicker.backgroundColor = [UIColor clearColor];
                CGAffineTransform rotate = CGAffineTransformMakeRotation(-3.14/2);
                [self.variencePicker setTransform:rotate];
                self.variencePicker.autoresizingMask = UIViewAutoresizingFlexibleHeight|UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleLeftMargin|UIViewAutoresizingFlexibleRightMargin|UIViewAutoresizingFlexibleTopMargin;;
                [self addSubview:self.variencePicker];
                
                self.currentProduct.varienceSelected = 0;
                
                ProductVarience *varience =[self.currentProduct getSelectedVareince];
                self.price.text = [NSString stringWithFormat:@"%0.2f",varience.price];
                
                if(varience.quantity>0)
                {
                    
                    self.error.hidden=YES;
                    
                    self.currentProduct.quantitySelected =1;
                    
                    self.quantityPicker = [[UIPickerView alloc] initWithFrame:CGRectMake(self.frame.size.width/2-20,75, 30, 300)];
                    [self.quantityPicker setDelegate:self];
                    [self.quantityPicker setDataSource:self];
                    self.quantityPicker.showsSelectionIndicator =YES;
                    self.quantityPicker.backgroundColor = [UIColor clearColor];
                    CGAffineTransform rotate = CGAffineTransformMakeRotation(-3.14/2);
                    [self.quantityPicker setTransform:rotate];
                    [self addSubview:self.quantityPicker];
                    
                    
                    
                }else
                {
                    self.error.hidden=NO;
                    self.error.text = @"Out of Stock";
                }
            }else
            {
                self.error.hidden=NO;
                self.error.text = @"Out of Stock";
            }
            
            
        }
    }
}

-(void)addProductToCart
{
    [self.delegate addProductToCart:self.currentProduct];
}


#pragma pickerview delegate

- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view
{
    
    CGRect rect=CGRectZero;
    
    if([pickerView isEqual:self.variencePicker])
    {
        rect = CGRectMake(0, 0, 80, 40);
        
    }else
    {
        rect = CGRectMake(0, 0, 60, 30);
    }
    
    UILabel *label = [[UILabel alloc]initWithFrame:rect];
    CGAffineTransform rotate = CGAffineTransformMakeRotation(3.14/2);
    //rotate = CGAffineTransformScale(rotate, 0.25, 2.0);
    [label setTransform:rotate];
    
    label.font = [UIFont systemFontOfSize:22.0];
    label.textAlignment = NSTextAlignmentCenter;
    label.numberOfLines = 2;
    label.lineBreakMode = NSLineBreakByWordWrapping;
    label.backgroundColor = [UIColor clearColor];
    label.clipsToBounds = YES;
    [label setFont:[UIFont fontWithName:@"HelveticaNeue-Thin" size:16.0f]];
    
    if([pickerView isEqual:self.variencePicker])
    {
        label.text = [[self.currentProduct.varienceList objectAtIndex:row] name];
        
    }else
    {
        label.text = [NSString stringWithFormat:@"Qty : %d",(int)row+1];
    }
    return label ;
}

-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}

-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    if([pickerView isEqual:self.variencePicker])
    {
        return self.currentProduct.varienceList.count;
        
    }else{
        ProductVarience *varience =  [self.currentProduct getSelectedVareince];
        return varience.quantity+30;
    }
}

-(double)pickerView:(UIPickerView *)pickerView rowHeightForComponent:(NSInteger)component
{
    if([pickerView isEqual:self.variencePicker])
    {
        return 80;
    }else{
        return 60;
    }
}

-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    if([pickerView isEqual:self.variencePicker])
    {
        self.currentProduct.varienceSelected = (int)row;
        ProductVarience *varience =  [self.currentProduct.varienceList objectAtIndex:row];
        self.price.text = [NSString stringWithFormat:@"%0.2f",varience.price];
        
        if(varience.quantity>0)
        {
            self.quantityPicker.hidden=NO;
            [self.quantityPicker reloadAllComponents];
            [self.quantityPicker selectRow:0 inComponent:0 animated:YES];
            
        }else
        {
            self.error.text = @"Out of Stock";
            self.quantityPicker.hidden=YES;
            
        }
        
    }else
    {
         ProductVarience *varience =  [self.currentProduct getSelectedVareince];
        self.currentProduct.quantitySelected =row+1;
         self.price.text = [NSString stringWithFormat:@"%0.2f",(varience.price)*(row+1)];
    }
}

@end
