//
//  ProductActionSet.m
//  ShoppingCart
//
//  Created by Sunkara, Radha Phani on 15/10/14.
//  Copyright (c) 2014 com.sample.shoppingcart. All rights reserved.
//

#import "ProductActionSet.h"
#import "ConnectionManager.h"
#import "ShoppingCart.h"

@implementation ProductActionSet

-(id)initWithProductSet:(NSArray *)array withAction:(NSString *)action withDelegate:(id<ProductActionSetDelegate>)delegate
{
    
    
    if(self =[super init])
    {
        self.action =action;
        self.products =array;
        self.delegate =delegate;
    }
    
    return self;
}

-(void)performAction
{
    NSMutableArray *items = [[NSMutableArray alloc] init];
    for (int i=0; i<self.products.count; i++) {
        
        Product *product = [self.products objectAtIndex:i];
        ProductVarience *varience = [product getSelectedVareince];
        
        NSString *itemId = [NSString stringWithFormat:@"%d",varience.id];
        NSString *quantity = [NSString stringWithFormat:@"%d",(int)product.quantitySelected];
        NSString *price = [NSString stringWithFormat:@"%f",varience.price];
        
        NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
        [dict setObject:itemId forKey:@"itemId"];
        [dict setObject:quantity forKey:@"quantity"];
        [dict setObject:price forKey:@"price"];
        
        [items addObject:dict];
    }
    
    ConnectionManager *manager = [ConnectionManager getInstance];
    
    NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:nil];
    [manager prepareRequestForShopConnection:postRequest withService:@"packitems" isPost:YES];
    
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
    [dict setObject:self.action forKey:@"state"];
    [dict setObject:items forKey:@"items"];
    
    NSError *error =nil;
    NSData *jsonData=[NSJSONSerialization dataWithJSONObject:dict options:NSJSONWritingPrettyPrinted error:&error];
    
    [postRequest setHTTPBody:jsonData];
    
    HttpsOperations *operation = [[HttpsOperations alloc] initWithRequest:postRequest withDelegate:self];
    [manager.serailQueue addOperation:operation];
    
    self.operation =operation;
}

#pragma mark - opeartion delegate

-(void)operationFinishedWithdata:(HttpsOperations *)operation
{
    [self.delegate actionComplete:self];
}
@end
