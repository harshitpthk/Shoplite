//
//  ShoppingCart.m
//  ShoppingCart
//
//  Created by Sunkara, Radha Phani on 14/10/14.
//  Copyright (c) 2014 com.sample.shoppingcart. All rights reserved.
//

#import "ShoppingCart.h"
static ShoppingCart* _manager=nil;

@implementation ShoppingCart

+(ShoppingCart*)getInstance
{
    @synchronized([ShoppingCart class])
    {
        if (!_manager)
        {
            _manager = [[self alloc] init];
            
            _manager.productsAtClient =[[NSMutableArray alloc] init];
            _manager.productsAtServer =[[NSMutableArray alloc] init];
            _manager.currentActionSetArray =[[NSMutableArray alloc] init];
        }
        return _manager;
    }
    
    return nil;
}

-(void)addProduct:(Product *)product
{
    [self.productsAtClient addObject:product];
    
    if(!self.currentPendingInsertSet)
    {
        self.currentPendingInsertSet =[[NSMutableArray alloc] init];
        [self.currentPendingInsertSet  addObject:product];
    }
    
    if(self.currentPendingInsertSet.count ==3)
    {
        ProductActionSet *action =[[ProductActionSet alloc] initWithProductSet:self.currentPendingInsertSet withAction:@"INSERT" withDelegate:self];
        
        [action performAction];
        [self.currentActionSetArray addObject:action];
        self.currentPendingInsertSet=nil;
        
    }
}

-(void)removeProduct:(Product *)product
{
    [self.productsAtClient removeObject:product];
    
    if(self.currentPendingInsertSet && [self.currentPendingInsertSet containsObject:product])
    {
        [self.currentPendingInsertSet  removeObject:product];
        
    }else
    {
        ProductActionSet *action =[[ProductActionSet alloc] initWithProductSet:[NSArray arrayWithObject:product]withAction:@"DELETE" withDelegate:self];
        
        [action performAction];
        [self.currentActionSetArray addObject:action];
    }
}

-(void)actionComplete:(ProductActionSet *)actionSet
{
    if([@"INSERT" isEqualToString:actionSet.action])
    {
        [self.productsAtServer addObjectsFromArray:actionSet.products];
        [self.currentActionSetArray removeObject:actionSet];
        
    }else if([@"DELETE" isEqualToString:actionSet.action])
    {
        [self.productsAtServer removeObjectsInArray:actionSet.products];
        [self.currentActionSetArray removeObject:actionSet];
    }
}
@end
