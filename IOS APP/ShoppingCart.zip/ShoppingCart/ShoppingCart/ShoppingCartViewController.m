//
//  SCartItemsController.m
//  ShoppingCart
//
//  Created by Ayyanababu, Kopparthi Raja on 15/09/14.
//  Copyright (c) 2014 com.sample.shoppingcart. All rights reserved.
//

#import "ShoppingCartViewController.h"

@interface ShoppingCartViewController ()

@end

@implementation ShoppingCartViewController

@synthesize cartProducts;
@synthesize productTable;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        ShoppingCart *shoppingCart  =[ShoppingCart getInstance];
        [self.view setBackgroundColor:[UIColor lightGrayColor]];
        self.cartProducts =shoppingCart.productsAtClient;
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.productTable = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height) style:UITableViewStylePlain];
    
    self.productTable.delegate =self;
    self.productTable.dataSource=self;
    self.productTable.allowsMultipleSelectionDuringEditing = NO;
    
    

    
    [self.view addSubview:self.productTable];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - tableViewDelegate
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    Product *product = [self.cartProducts objectAtIndex:indexPath.row];
    
    static NSString *CellIdentifier = @"Cell";
    
    ProductTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[ProductTableViewCell alloc] initWithProduct:product reuseIdentifier:CellIdentifier];
    }
    
    return cell;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.cartProducts.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 80;
}

// Override to support conditional editing of the table view.
// This only needs to be implemented if you are going to be returning NO
// for some items. By default, all items are editable.
//- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
//    // Return YES if you want the specified item to be editable.
//    return YES;
//}

// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        
        Product *product = [self.cartProducts objectAtIndex:indexPath.row];
        ShoppingCart *shoppingCart  =[ShoppingCart getInstance];
        [shoppingCart removeProduct:product];
        
        [self.productTable deleteRowsAtIndexPaths:[NSArray arrayWithObjects:indexPath, nil] withRowAnimation:UITableViewRowAnimationLeft];
    }
}

@end
