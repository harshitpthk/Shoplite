//
//  SCartCenterViewController.m
//  ShoppingCart
//
//  Created by Ayyanababu, Kopparthi Raja on 10/09/14.
//  Copyright (c) 2014 com.sample.shoppingcart. All rights reserved.
//

#import "CenterViewController.h"
#import "KeychainWrapper.h"
#import "ConnectionManager.h"
#import "Shop.h"
#import "Product.h"

static int productViewTag = 222;
@interface CenterViewController ()

@end

@implementation CenterViewController


@synthesize delegate;
@synthesize leftButton;
@synthesize mapViewButton;
@synthesize rightButton;
@synthesize isMapViewVisible;
@synthesize itemController;
@synthesize captureSession = _captureSession;
@synthesize videoPreviewLayer = _videoPreviewLayer;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        //[self.view setBackgroundColor:[UIColor purpleColor]];
        
        //Adding button Navigation Items
        leftButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCompose target:self action:@selector(showLeftMenu:)];
        leftButton.tag = 1;
        self.navigationItem.leftBarButtonItem = leftButton;
        
        self.mapViewButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
        [self.mapViewButton addTarget:self action:@selector(clickOnMapView) forControlEvents:UIControlEventTouchDown];
        self.navigationItem.titleView = self.mapViewButton;
        
        
        rightButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCompose target:self action:@selector(showRightMenu:)];
        self.navigationItem.rightBarButtonItem = rightButton;
        
        self.isMapViewVisible = YES;
        
         [self loginToStar];
        
    }
    return self;
}



- (void)viewDidLoad
{
    [super viewDidLoad];
    _isReading = NO;
    
    [self startScanning];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)loginToStar
{
    
    ConnectionManager *manager = [ConnectionManager getInstance];
    
    NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:nil];
    [manager prepareRequestForStarConnection:postRequest withService:@"login" isPost:YES];
    
    [postRequest setValue:[Utility getUniqueSession] forHTTPHeaderField:@"shoplite-client-id"];
    
    KeychainWrapper *keyChain = [KeychainWrapper getInstance];
    NSData *data = [keyChain myObjectForKey:(__bridge id)kSecAttrAccount];
    NSDictionary *dict = [NSKeyedUnarchiver unarchiveObjectWithData:(NSData *)data];
    
    
    NSArray *array = [NSArray arrayWithObject:[dict objectForKey:@"email"]];
    
    NSError *error =nil;
    NSData *jsonData=[NSJSONSerialization dataWithJSONObject:array options:NSJSONWritingPrettyPrinted error:&error];
    
    [postRequest setHTTPBody:jsonData];
    
    
    HttpsOperations *operation = [[HttpsOperations alloc] initWithRequest:postRequest withDelegate:self];
    [manager.serailQueue addOperation:operation];
    
    loginStarOperation = operation;
    
}

-(void)getShop
{
    ConnectionManager *manager = [ConnectionManager getInstance];
    
    NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:nil];
    [manager prepareRequestForStarConnection:postRequest withService:@"getshop" isPost:YES];
    
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
    [dict setObject:@"12.9854762" forKey:@"latitude"];
    [dict setObject:@"77.7101112" forKey:@"longitude"];
    
    NSError *error =nil;
    NSData *jsonData=[NSJSONSerialization dataWithJSONObject:dict options:NSJSONWritingPrettyPrinted error:&error];
    
    [postRequest setHTTPBody:jsonData];
    
    HttpsOperations *operation = [[HttpsOperations alloc] initWithRequest:postRequest withDelegate:self];
    [manager.serailQueue addOperation:operation];
    
    getShopOperation = operation;
    
}

-(void)loginToShop:(NSString *)sessionToken
{
    ConnectionManager *manager = [ConnectionManager getInstance];
    
    NSMutableURLRequest *postRequest = [NSMutableURLRequest requestWithURL:nil];
    [manager prepareRequestForShopConnection:postRequest withService:@"login" isPost:YES];
    
    NSArray *array = [NSArray arrayWithObject:sessionToken];
    NSError *error =nil;
    NSData *jsonData=[NSJSONSerialization dataWithJSONObject:array options:NSJSONWritingPrettyPrinted error:&error];
    
    [postRequest setHTTPBody:jsonData];
    

    HttpsOperations *operation = [[HttpsOperations alloc] initWithRequest:postRequest withDelegate:self];
    [manager.serailQueue addOperation:operation];
    
    loginShopOperation = operation;
}

#pragma mark - opeartion delegate

-(void)operationFinishedWithdata:(HttpsOperations *)operation
{
    if([operation isEqual:loginStarOperation])
    {
        NSString* newStr = [[NSString alloc] initWithData:operation.receivedData encoding:NSUTF8StringEncoding];
        
        //change at server
        if([@"\"success\"" isEqualToString:newStr])
        {
            NSString *sessionToken = [operation.headers objectForKey:@"Set-Cookie"];
            if(sessionToken)
                [ConnectionManager getInstance].currentStarToken =sessionToken;
            
            [self getShop];
        }
        
    }else if([operation isEqual:getShopOperation])
    {
        
        NSError *e = nil;
        NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:operation.receivedData options: NSJSONReadingMutableContainers error: &e];
        if(dict!=nil)
        {
            Shop *shop =[[Shop alloc] init];
            
            shop.name = [dict objectForKey:@"name"];
            shop.url = [dict objectForKey:@"url"];
            shop.location =[dict objectForKey:@"location"];
            [ConnectionManager getInstance].currentShop =shop;
            
            [self loginToShop:[ConnectionManager getInstance].currentStarToken];
        }
        
    }else if([operation isEqual:loginShopOperation])
    {
        NSString* newStr = [[NSString alloc] initWithData:operation.receivedData encoding:NSUTF8StringEncoding];
        
        
        if([@"success" isEqualToString:newStr])
        {
            
        }
    }
}

#pragma mark QR SCanner
#pragma mark ----------

- (void) startScanning
{
    self.productId = [[UITextField alloc] initWithFrame:CGRectMake(10, self.view.frame.origin.y + 80, 150, 30)];
    self.productId.placeholder = @"Phone No";
    self.productId.textAlignment = NSTextAlignmentLeft;
    self.productId.font = [UIFont fontWithName:@"HelveticaNeue-Thin" size:14.0];
    self.productId.adjustsFontSizeToFitWidth = YES;
    self.productId.textColor = [UIColor blackColor];
    self.productId.keyboardType = UIKeyboardTypeNumberPad;
    self.productId.returnKeyType = UIReturnKeyDone;
    self.productId.clearButtonMode = UITextFieldViewModeWhileEditing;
    
    
    [self.view addSubview:self.productId];
    
    self.fetch = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [self.fetch setTitle:@"Fetch" forState:UIControlStateNormal];
    [self.fetch setTitleColor:[UIColor purpleColor] forState:UIControlStateNormal];
    self.fetch.layer.cornerRadius = 4;
    self.fetch.layer.borderWidth = 1.0;
    self.fetch.layer.borderColor = [UIColor purpleColor].CGColor;
    [self.fetch.titleLabel setFont:[UIFont fontWithName:@"HelveticaNeue-Thin" size:16.0f]];
    [self.fetch.titleLabel setTextAlignment:NSTextAlignmentRight];
    [self.fetch addTarget:self action:@selector(showProduct) forControlEvents:UIControlEventTouchDown];
    
    [self.fetch setFrame:CGRectMake(200, self.view.frame.origin.y + 80, 80, 30)];
    [self.view addSubview:self.fetch];
}

-(void)showProduct
{
    Product *product =[[Product alloc] init];
    product.id = [[self.productId text] integerValue];
    
    UIView *prevView = [self.view viewWithTag:productViewTag] ;
    
    if(prevView)
    {
        [prevView removeFromSuperview];
    }
    
    ProductInfoView1 *view = [[ProductInfoView1 alloc] initWithFrame:CGRectMake(40, self.view.frame.origin.y + 150, self.view.frame.size.width-2*40, 260) withProduct:product];
    view.layer.cornerRadius = 4;
    view.layer.borderWidth = 1.0;
    view.layer.borderColor = [UIColor purpleColor].CGColor;
    view.tag =productViewTag;
    view.delegate =self;
    [self.view addSubview:view];
}

#pragma mark productInfoViewDelgate
-(void)addProductToCart:(Product *)product
{
    UIView *prevView = [self.view viewWithTag:productViewTag] ;
    
//    CABasicAnimation *fadeOutAnimation = [CABasicAnimation animationWithKeyPath:@"opacity"];
//    [fadeOutAnimation setToValue:[NSNumber numberWithFloat:0.2]];
//    fadeOutAnimation.fillMode = kCAFillModeForwards;
//    fadeOutAnimation.removedOnCompletion = NO;
//    
//    // Set up scaling
//    CABasicAnimation *resizeAnimation = [CABasicAnimation animationWithKeyPath:@"bounds.size"];
//    [resizeAnimation setToValue:[NSValue valueWithCGSize:CGSizeMake(10,10)]];
//    resizeAnimation.fillMode = kCAFillModeForwards;
//    resizeAnimation.removedOnCompletion = NO;
//    
//    // Set up path movement
//    CABasicAnimation *pathAnimation = [CABasicAnimation animationWithKeyPath:@"position"];
//    [pathAnimation setToValue:[NSValue valueWithCGPoint:CGPointMake(self.view.frame.size.width-80, 20)]];
//    pathAnimation.fillMode = kCAFillModeForwards;
//    pathAnimation.removedOnCompletion = NO;
//    
//    
//    CAAnimationGroup *group = [CAAnimationGroup animation];
//    group.fillMode = kCAFillModeForwards;
//    group.removedOnCompletion = NO;
//    [group setAnimations:[NSArray arrayWithObjects:fadeOutAnimation, pathAnimation, resizeAnimation, nil]];
//    group.duration = 0.7f;
//    [group setValue:prevView forKey:@"imageViewBeingAnimated"];
//    
//    [prevView.layer addAnimation:group forKey:@"savingAnimation"];
    
    [UIView animateWithDuration:0.6f
                     delay: 0.0f
                     options: UIViewAnimationOptionCurveEaseIn
                     animations:^{
                         prevView.transform =CGAffineTransformMakeScale(0.1, 0.1);
                         prevView.center =CGPointMake(self.view.frame.size.width-20, 0);
                         prevView.layer.opacity =0.1;
                     }
                     completion:^(BOOL finished){
                         [prevView removeFromSuperview];
                     }
     ];
    
    ShoppingCart *shoppingCart  =[ShoppingCart getInstance];
    [shoppingCart addProduct:product];
}

#pragma mark RightButtonMethod
#pragma mark -----------------

- (void) showRightMenu:(id)sender
{
    
    
    self.itemController = [[ShoppingCartViewController alloc] initWithNibName:nil bundle:nil];
    
    
   /* CATransition* transition = [CATransition animation];
    transition.duration = 0.25;
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    transition.type = kCATransitionPush; //kCATransitionMoveIn; //, kCATransitionPush, kCATransitionReveal, kCATransitionFade
    transition.subtype = kCATransitionFromLeft; //kCATransitionFromLeft, kCATransitionFromRight, kCATransitionFromTop, kCATransitionFromBottom
    
    
    
    [self.navigationController.view.layer addAnimation:transition forKey:kCATransition];
    */
    [self.navigationController pushViewController:self.itemController animated:YES];
}


#pragma mark MapViewButton Method
#pragma mark --------------------

- (void) clickOnMapView
{

    if(self.isMapViewVisible)
    {

        [self setIsMapViewVisible:NO];
        self.mapView = [[MKMapView alloc] initWithFrame:CGRectMake(30, 80, self.view.frame.size.width-60 , self.view.frame.size.height-120)];
        self.mapView.showsUserLocation = YES;
        self.mapView.autoresizingMask = UIViewAutoresizingFlexibleHeight|UIViewAutoresizingFlexibleWidth;
        self.mapView.delegate = self;
        [self.mapView.layer setBorderWidth:2.0f];
        [self.mapView setUserTrackingMode:MKUserTrackingModeFollow animated:YES];
        [self.mapView.layer setBorderColor:[UIColor purpleColor].CGColor];
        [self.mapView.layer setCornerRadius:5.0f];
        [self.mapView setUserTrackingMode:MKUserTrackingModeFollow animated:YES];
        
        self.mapView.showsUserLocation = YES;
        self.mapView.mapType = MKMapTypeStandard;
        
        [self.mapView setUserTrackingMode:MKUserTrackingModeFollow animated:YES];
        
        [self.view addSubview:self.mapView];
    }
    else{
        self.isMapViewVisible = YES;
        [self.mapView removeFromSuperview];
    }
    
    
    
}

#pragma mark MapViewDelegate Method
#pragma mark ----------------------

-(void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation {
    [self.mapView setCenterCoordinate:userLocation.coordinate animated:YES];
}


#pragma mark LeftButton Method
#pragma mark -----------------

- (void) showLeftMenu:(id)sender

{
    UIBarButtonItem *button = sender;
    switch (button.tag) {
        case 0:{
            //[close the centerviewscreen]
            [self.delegate movePanelToOriginalPosition];
            break;
        }
        case 1:{
            [self.delegate movePanelRight];
        }
        
        default:
            break;
        
    }
}


#pragma mark QR Scanner Methods
#pragma mark ------------------

- (BOOL)startReading
{
    NSError *error;
    
    AVCaptureDevice *captureDevice = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
    
    AVCaptureDeviceInput *input = [AVCaptureDeviceInput deviceInputWithDevice:captureDevice error:&error];
    if (!input) {
        NSLog(@"%@", [error localizedDescription]);
        return NO;
    }
    
    _captureSession = [[AVCaptureSession alloc] init];
    [_captureSession addInput:input];
    
    AVCaptureMetadataOutput *captureMetadataOutput = [[AVCaptureMetadataOutput alloc] init];
    [_captureSession addOutput:captureMetadataOutput];
    
    dispatch_queue_t dispatchQueue;
    dispatchQueue = dispatch_queue_create("myQueue", NULL);
    [captureMetadataOutput setMetadataObjectsDelegate:self queue:dispatchQueue];
    [captureMetadataOutput setMetadataObjectTypes:[NSArray arrayWithObject:AVMetadataObjectTypeQRCode]];
    
    _videoPreviewLayer = [[AVCaptureVideoPreviewLayer alloc] initWithSession:_captureSession];
    [_videoPreviewLayer setVideoGravity:AVLayerVideoGravityResizeAspectFill];
    [_videoPreviewLayer setFrame:self.view.bounds];
    [self.view.layer addSublayer:_videoPreviewLayer];
    
    [_captureSession startRunning];
    
    return YES;
}



@end
